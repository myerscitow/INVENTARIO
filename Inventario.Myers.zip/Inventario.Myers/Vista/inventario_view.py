from Modelo.producto import Producto
import flet as ft


# Lista temporal de productos
productos = []


# Vista principal
class InventarioView:

    def mostrar_mensaje(self, mensaje):
        print(f">>> {mensaje}")


# Aplicación Flet
def main(page: ft.Page):

    # Configuración de ventana
    page.title = "Sistema de Inventario"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.window_width = 950
    page.window_height = 700
    page.padding = 20
    page.scroll = "auto"

    # Título
    titulo = ft.Text(
        "Sistema de Inventario",
        size=28,
        weight=ft.FontWeight.BOLD
    )

    # Campos de entrada
    txt_nombre = ft.TextField(
        label="Nombre",
        width=300
    )

    txt_precio = ft.TextField(
        label="Precio",
        width=300
    )

    txt_stock = ft.TextField(
        label="Stock",
        width=300
    )

    txt_categoria = ft.TextField(
        label="Categoría",
        width=300
    )

    # Área donde se mostrarán productos
    lista_productos = ft.Column()

    # Campos actualización
    txt_id = ft.TextField(
        label="ID Producto",
        width=300
    )

    txt_nuevo_stock = ft.TextField(
        label="Nuevo Stock",
        width=300
    )

    # Mensajes
    mensaje = ft.Text("")

    # Función registrar producto
    def registrar_producto(e):

        try:
            producto = {
                "id": len(productos) + 1,
                "nombre": txt_nombre.value,
                "precio": float(txt_precio.value),
                "stock": int(txt_stock.value),
                "categoria": txt_categoria.value
            }

            productos.append(producto)

            mensaje.value = "Producto registrado correctamente."

            txt_nombre.value = ""
            txt_precio.value = ""
            txt_stock.value = ""
            txt_categoria.value = ""

            page.update()

        except:
            mensaje.value = "Error al registrar producto."
            page.update()

    # Función mostrar productos
    def mostrar_productos(e):

        lista_productos.controls.clear()

        if productos:

            for producto in productos:

                lista_productos.controls.append(
                    ft.Text(
                        f'ID: {producto["id"]} | '
                        f'Nombre: {producto["nombre"]} | '
                        f'Precio: ${producto["precio"]} | '
                        f'Stock: {producto["stock"]} | '
                        f'Categoría: {producto["categoria"]}'
                    )
                )

        else:
            lista_productos.controls.append(
                ft.Text("No hay productos registrados.")
            )

        page.update()

    # Función actualizar stock
    def actualizar_stock(e):

        try:
            id_producto = int(txt_id.value)
            nuevo_stock = int(txt_nuevo_stock.value)

            encontrado = False

            for producto in productos:

                if producto["id"] == id_producto:

                    producto["stock"] = nuevo_stock
                    encontrado = True
                    break

            if encontrado:
                mensaje.value = "Stock actualizado correctamente."
            else:
                mensaje.value = "Producto no encontrado."

            page.update()

        except:
            mensaje.value = "Datos inválidos."
            page.update()

    # Función eliminar producto
    def eliminar_producto(e):

        try:
            id_producto = int(txt_id.value)

            eliminado = False

            for producto in productos:

                if producto["id"] == id_producto:

                    productos.remove(producto)
                    eliminado = True
                    break

            if eliminado:
                mensaje.value = "Producto eliminado correctamente."
            else:
                mensaje.value = "Producto no encontrado."

            page.update()

        except:
            mensaje.value = "Error al eliminar producto."
            page.update()

    # Botones
    btn_registrar = ft.ElevatedButton(
        "Registrar Producto",
        on_click=registrar_producto
    )

    btn_mostrar = ft.ElevatedButton(
        "Mostrar Productos",
        on_click=mostrar_productos
    )

    btn_actualizar = ft.ElevatedButton(
        "Actualizar Stock",
        on_click=actualizar_stock
    )

    btn_eliminar = ft.ElevatedButton(
        "Eliminar Producto",
        on_click=eliminar_producto
    )

    # Agregar elementos
    page.add(
        titulo,

        txt_nombre,
        txt_precio,
        txt_stock,
        txt_categoria,

        btn_registrar,

        ft.Divider(),

        btn_mostrar,

        lista_productos,

        ft.Divider(),

        txt_id,
        txt_nuevo_stock,

        btn_actualizar,
        btn_eliminar,

        ft.Divider(),

        mensaje
    )


# Ejecutar aplicación
ft.app(target=main)