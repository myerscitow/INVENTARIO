import flet as ft
from Controlador.inventario_controller import InventarioController


# Función principal de la aplicación
def main(page: ft.Page):

    # Configuración de la ventana
    page.title = "Gestor de Inventario"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.window_width = 900
    page.window_height = 600
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    # Inicializar controlador principal
    sistema = InventarioController(page)

    # Iniciar aplicación
    sistema.iniciar()


# Ejecutar aplicación Flet
ft.app(target=main)